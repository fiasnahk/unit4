﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace event_managment
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {

            string Username = "U123";
            string password = "Password123";
            if (txtUsername.Text == Username && txtPassword.Text == password)
            {
                MessageBox.Show("Login successful");
                Form1 frm1 = new Form1();
                frm1.Show();

            }
            else MessageBox.Show("Please enter valid username and password");

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
