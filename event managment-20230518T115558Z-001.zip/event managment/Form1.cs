﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace event_managment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAddNewPlayer_Click(object sender, EventArgs e)      
         {
            if (txtPlayer.Text == "")
            {
                MessageBox.Show("Please enter a player name");
            }
            else
            {

                File.AppendAllLines("Player.txt", new string[] { txtPlayer.Text });
                txtPlayer.Text = "";
                MessageBox.Show("New player added");
                MessageBox.Show("please enter a player name");
                ShowPlayerData();
            }
        }
        void ShowPlayerData()
        {
            lstPlayers.Items.Clear();
            foreach (string line in File.ReadLines(@"Player.txt", Encoding.UTF8))
            {
                // process the line
                lstPlayers.Items.Add(line);
            }
            lstPlayers.Show();
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            if (txtTeams.Text == "")
            {
                MessageBox.Show("Please enter a team name");
            }
            else
            {


                File.AppendAllLines("Teams.txt", new string[] { txtTeams.Text });
                txtTeams.Text = "";
                MessageBox.Show("New Team added");
            }
            ShowTeamData();
        }

        void ShowTeamData()
        {
            lstTeams.Items.Clear();
            foreach (string line in File.ReadLines(@"teams.txt", Encoding.UTF8))
            {
                // process the line
                lstTeams.Items.Add(line);
            }
            lstTeams.Show();
        }

        private void btnAddNewEvent_Click(object sender, EventArgs e)
        {
            if (txtEvent.Text == "")
            {
                MessageBox.Show("Please enter new event");
            }
            else
            {


                File.AppendAllLines(
                "Events.txt",
                contents: new string[] { txtEvent.Text });



                txtEvent.Text = "";
                MessageBox.Show("New event added");
            }
            showEventdata();


        }
        void showEventdata()


        {
            lstEvents.ClearSelected();
            foreach (string line in File.ReadLines(@"Events.txt", Encoding.UTF8))
            {
                lstEvents.Items.Add(line);
            }
            lstEvents.Show();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtPlayer.Text == "" && txtFirstScore.Text == "" && txtSecondScore.Text == "" && txtThirdScore.Text == "" && txtFourthScore.Text == "")
            {
                MessageBox.Show("Please enter a team  name");
                MessageBox.Show("please enter the first score ");
                MessageBox.Show("please enter the second score");
                MessageBox.Show("please enter the third score");
                MessageBox.Show("please enter the fourth score");
            }
            
           else {
                int score1 = Convert.ToInt32(txtFirstScore.Text);
                int score2 = Convert.ToInt32(txtSecondScore.Text);
                int score3 = Convert.ToInt32(txtThirdScore.Text);
                int score4 = Convert.ToInt32(txtFirstScore.Text);
                int TotalScore = score1 + score2 + score3 + score4;
                lblTotalScore.Text = Convert.ToString(TotalScore);


                score1 = Convert.ToInt32(txtFirstScore.Text);
                score2 = Convert.ToInt32(txtSecondScore.Text);
                score3 = Convert.ToInt32(txtThirdScore.Text);
                score4 = Convert.ToInt32(txtFourthScore.Text);

                TotalScore = score1 + score2 + score3 + score4;
                lblTotalScore.Text = Convert.ToString(TotalScore);

                File.AppendAllLines("TeamScore.txt", new string[] { txtTeam.Text + " : " + lblTotalScore.Text });

                MessageBox.Show("Total Team Score is added");
                ShowTeamScoreData();
            }

        }

        void ShowTeamScoreData()
        {
            lstScores.Items.Clear();
            foreach (string line in File.ReadLines(@"TeamScore.txt", Encoding.UTF8))
            {
                // process the line
                lstScores.Items.Add(line);
            }
            lstScores.Show();
        }

    }
}






