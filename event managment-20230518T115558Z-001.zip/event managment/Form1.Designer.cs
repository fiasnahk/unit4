﻿
namespace event_managment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddNewPlayer = new System.Windows.Forms.Button();
            this.txtPlayer = new System.Windows.Forms.TextBox();
            this.lstPlayers = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.AddEvent = new System.Windows.Forms.TabPage();
            this.btnAddNewEvent = new System.Windows.Forms.Button();
            this.lstEvents = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEvent = new System.Windows.Forms.TextBox();
            this.AddPlayers = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.AddTeam = new System.Windows.Forms.TabPage();
            this.btnAddTeam = new System.Windows.Forms.Button();
            this.lstTeams = new System.Windows.Forms.ListBox();
            this.AddNewTeam = new System.Windows.Forms.Label();
            this.txtTeams = new System.Windows.Forms.TextBox();
            this.Score = new System.Windows.Forms.TabPage();
            this.lblTeam = new System.Windows.Forms.Label();
            this.txtTeam = new System.Windows.Forms.TextBox();
            this.lstScores = new System.Windows.Forms.ListBox();
            this.lblTotalScore = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblFourthScore = new System.Windows.Forms.Label();
            this.lblThirdScore = new System.Windows.Forms.Label();
            this.lblSecondScore = new System.Windows.Forms.Label();
            this.lblFirstScore = new System.Windows.Forms.Label();
            this.txtFourthScore = new System.Windows.Forms.TextBox();
            this.txtThirdScore = new System.Windows.Forms.TextBox();
            this.txtSecondScore = new System.Windows.Forms.TextBox();
            this.txtFirstScore = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.AddEvent.SuspendLayout();
            this.AddPlayers.SuspendLayout();
            this.AddTeam.SuspendLayout();
            this.Score.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddNewPlayer
            // 
            this.btnAddNewPlayer.BackColor = System.Drawing.Color.Goldenrod;
            this.btnAddNewPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewPlayer.Location = new System.Drawing.Point(258, 276);
            this.btnAddNewPlayer.Name = "btnAddNewPlayer";
            this.btnAddNewPlayer.Size = new System.Drawing.Size(157, 31);
            this.btnAddNewPlayer.TabIndex = 0;
            this.btnAddNewPlayer.Text = "AddPlayertab";
            this.btnAddNewPlayer.UseVisualStyleBackColor = false;
            this.btnAddNewPlayer.Click += new System.EventHandler(this.btnAddNewPlayer_Click);
            // 
            // txtPlayer
            // 
            this.txtPlayer.BackColor = System.Drawing.Color.Goldenrod;
            this.txtPlayer.Location = new System.Drawing.Point(198, 112);
            this.txtPlayer.Name = "txtPlayer";
            this.txtPlayer.Size = new System.Drawing.Size(100, 20);
            this.txtPlayer.TabIndex = 1;
            // 
            // lstPlayers
            // 
            this.lstPlayers.BackColor = System.Drawing.Color.Goldenrod;
            this.lstPlayers.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstPlayers.FormattingEnabled = true;
            this.lstPlayers.ItemHeight = 24;
            this.lstPlayers.Location = new System.Drawing.Point(42, 183);
            this.lstPlayers.Name = "lstPlayers";
            this.lstPlayers.Size = new System.Drawing.Size(120, 124);
            this.lstPlayers.TabIndex = 2;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.AddEvent);
            this.tabControl1.Controls.Add(this.AddPlayers);
            this.tabControl1.Controls.Add(this.AddTeam);
            this.tabControl1.Controls.Add(this.Score);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(789, 413);
            this.tabControl1.TabIndex = 3;
            // 
            // AddEvent
            // 
            this.AddEvent.Controls.Add(this.btnAddNewEvent);
            this.AddEvent.Controls.Add(this.lstEvents);
            this.AddEvent.Controls.Add(this.label2);
            this.AddEvent.Controls.Add(this.txtEvent);
            this.AddEvent.Controls.Add(this.pictureBox3);
            this.AddEvent.Location = new System.Drawing.Point(4, 22);
            this.AddEvent.Name = "AddEvent";
            this.AddEvent.Size = new System.Drawing.Size(781, 387);
            this.AddEvent.TabIndex = 2;
            this.AddEvent.Text = "addEvent";
            this.AddEvent.UseVisualStyleBackColor = true;
            // 
            // btnAddNewEvent
            // 
            this.btnAddNewEvent.BackColor = System.Drawing.Color.Goldenrod;
            this.btnAddNewEvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewEvent.Location = new System.Drawing.Point(210, 280);
            this.btnAddNewEvent.Name = "btnAddNewEvent";
            this.btnAddNewEvent.Size = new System.Drawing.Size(161, 59);
            this.btnAddNewEvent.TabIndex = 4;
            this.btnAddNewEvent.Text = "Add new event";
            this.btnAddNewEvent.UseVisualStyleBackColor = false;
            this.btnAddNewEvent.Click += new System.EventHandler(this.btnAddNewEvent_Click);
            // 
            // lstEvents
            // 
            this.lstEvents.BackColor = System.Drawing.Color.Goldenrod;
            this.lstEvents.FormattingEnabled = true;
            this.lstEvents.Location = new System.Drawing.Point(219, 119);
            this.lstEvents.Name = "lstEvents";
            this.lstEvents.Size = new System.Drawing.Size(127, 134);
            this.lstEvents.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Goldenrod;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Add new event";
            // 
            // txtEvent
            // 
            this.txtEvent.BackColor = System.Drawing.Color.Goldenrod;
            this.txtEvent.Location = new System.Drawing.Point(219, 44);
            this.txtEvent.Name = "txtEvent";
            this.txtEvent.Size = new System.Drawing.Size(92, 20);
            this.txtEvent.TabIndex = 1;
            // 
            // AddPlayers
            // 
            this.AddPlayers.Controls.Add(this.lstPlayers);
            this.AddPlayers.Controls.Add(this.btnAddNewPlayer);
            this.AddPlayers.Controls.Add(this.txtPlayer);
            this.AddPlayers.Controls.Add(this.label1);
            this.AddPlayers.Controls.Add(this.pictureBox1);
            this.AddPlayers.Location = new System.Drawing.Point(4, 22);
            this.AddPlayers.Name = "AddPlayers";
            this.AddPlayers.Padding = new System.Windows.Forms.Padding(3);
            this.AddPlayers.Size = new System.Drawing.Size(781, 387);
            this.AddPlayers.TabIndex = 0;
            this.AddPlayers.Text = "addPlayer";
            this.AddPlayers.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Goldenrod;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Add new player";
            // 
            // AddTeam
            // 
            this.AddTeam.Controls.Add(this.btnAddTeam);
            this.AddTeam.Controls.Add(this.lstTeams);
            this.AddTeam.Controls.Add(this.AddNewTeam);
            this.AddTeam.Controls.Add(this.txtTeams);
            this.AddTeam.Controls.Add(this.pictureBox2);
            this.AddTeam.Controls.Add(this.pictureBox5);
            this.AddTeam.Location = new System.Drawing.Point(4, 22);
            this.AddTeam.Name = "AddTeam";
            this.AddTeam.Padding = new System.Windows.Forms.Padding(3);
            this.AddTeam.Size = new System.Drawing.Size(781, 387);
            this.AddTeam.TabIndex = 1;
            this.AddTeam.Text = "AddTeams";
            this.AddTeam.UseVisualStyleBackColor = true;
            // 
            // btnAddTeam
            // 
            this.btnAddTeam.BackColor = System.Drawing.Color.Goldenrod;
            this.btnAddTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTeam.Location = new System.Drawing.Point(355, 272);
            this.btnAddTeam.Name = "btnAddTeam";
            this.btnAddTeam.Size = new System.Drawing.Size(99, 42);
            this.btnAddTeam.TabIndex = 2;
            this.btnAddTeam.Text = "submit";
            this.btnAddTeam.UseVisualStyleBackColor = false;
            this.btnAddTeam.Click += new System.EventHandler(this.btnAddTeam_Click);
            // 
            // lstTeams
            // 
            this.lstTeams.BackColor = System.Drawing.Color.Goldenrod;
            this.lstTeams.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTeams.FormattingEnabled = true;
            this.lstTeams.ItemHeight = 24;
            this.lstTeams.Location = new System.Drawing.Point(153, 147);
            this.lstTeams.Name = "lstTeams";
            this.lstTeams.Size = new System.Drawing.Size(142, 124);
            this.lstTeams.TabIndex = 1;
            // 
            // AddNewTeam
            // 
            this.AddNewTeam.AutoSize = true;
            this.AddNewTeam.BackColor = System.Drawing.Color.Goldenrod;
            this.AddNewTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewTeam.Location = new System.Drawing.Point(11, 68);
            this.AddNewTeam.Name = "AddNewTeam";
            this.AddNewTeam.Size = new System.Drawing.Size(144, 24);
            this.AddNewTeam.TabIndex = 3;
            this.AddNewTeam.Text = "Add new team";
            // 
            // txtTeams
            // 
            this.txtTeams.BackColor = System.Drawing.Color.Goldenrod;
            this.txtTeams.Location = new System.Drawing.Point(203, 73);
            this.txtTeams.Name = "txtTeams";
            this.txtTeams.Size = new System.Drawing.Size(92, 20);
            this.txtTeams.TabIndex = 0;
            // 
            // Score
            // 
            this.Score.Controls.Add(this.lblTeam);
            this.Score.Controls.Add(this.txtTeam);
            this.Score.Controls.Add(this.lstScores);
            this.Score.Controls.Add(this.lblTotalScore);
            this.Score.Controls.Add(this.lblScore);
            this.Score.Controls.Add(this.btnSubmit);
            this.Score.Controls.Add(this.lblFourthScore);
            this.Score.Controls.Add(this.lblThirdScore);
            this.Score.Controls.Add(this.lblSecondScore);
            this.Score.Controls.Add(this.lblFirstScore);
            this.Score.Controls.Add(this.txtFourthScore);
            this.Score.Controls.Add(this.txtThirdScore);
            this.Score.Controls.Add(this.txtSecondScore);
            this.Score.Controls.Add(this.txtFirstScore);
            this.Score.Controls.Add(this.pictureBox4);
            this.Score.Location = new System.Drawing.Point(4, 22);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(781, 387);
            this.Score.TabIndex = 3;
            this.Score.Text = "Score";
            this.Score.UseVisualStyleBackColor = true;
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.BackColor = System.Drawing.Color.Goldenrod;
            this.lblTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam.Location = new System.Drawing.Point(40, 31);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblTeam.Size = new System.Drawing.Size(121, 24);
            this.lblTeam.TabIndex = 14;
            this.lblTeam.Text = "Team name";
            // 
            // txtTeam
            // 
            this.txtTeam.BackColor = System.Drawing.Color.Goldenrod;
            this.txtTeam.Location = new System.Drawing.Point(194, 31);
            this.txtTeam.Name = "txtTeam";
            this.txtTeam.Size = new System.Drawing.Size(99, 20);
            this.txtTeam.TabIndex = 13;
            // 
            // lstScores
            // 
            this.lstScores.BackColor = System.Drawing.Color.Goldenrod;
            this.lstScores.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstScores.FormattingEnabled = true;
            this.lstScores.ItemHeight = 20;
            this.lstScores.Location = new System.Drawing.Point(395, 56);
            this.lstScores.Name = "lstScores";
            this.lstScores.Size = new System.Drawing.Size(162, 144);
            this.lstScores.TabIndex = 12;
            // 
            // lblTotalScore
            // 
            this.lblTotalScore.AutoSize = true;
            this.lblTotalScore.BackColor = System.Drawing.Color.Goldenrod;
            this.lblTotalScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalScore.Location = new System.Drawing.Point(205, 216);
            this.lblTotalScore.Name = "lblTotalScore";
            this.lblTotalScore.Size = new System.Drawing.Size(21, 24);
            this.lblTotalScore.TabIndex = 11;
            this.lblTotalScore.Text = "0";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.BackColor = System.Drawing.Color.Goldenrod;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(36, 216);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(65, 24);
            this.lblScore.TabIndex = 10;
            this.lblScore.Text = "Score";
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.Goldenrod;
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(230, 277);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(133, 56);
            this.btnSubmit.TabIndex = 9;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblFourthScore
            // 
            this.lblFourthScore.AutoSize = true;
            this.lblFourthScore.BackColor = System.Drawing.Color.Goldenrod;
            this.lblFourthScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFourthScore.Location = new System.Drawing.Point(36, 176);
            this.lblFourthScore.Name = "lblFourthScore";
            this.lblFourthScore.Size = new System.Drawing.Size(129, 24);
            this.lblFourthScore.TabIndex = 8;
            this.lblFourthScore.Text = "Fourth score";
            // 
            // lblThirdScore
            // 
            this.lblThirdScore.AutoSize = true;
            this.lblThirdScore.BackColor = System.Drawing.Color.Goldenrod;
            this.lblThirdScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThirdScore.Location = new System.Drawing.Point(36, 132);
            this.lblThirdScore.Name = "lblThirdScore";
            this.lblThirdScore.Size = new System.Drawing.Size(117, 24);
            this.lblThirdScore.TabIndex = 7;
            this.lblThirdScore.Text = "Third score";
            // 
            // lblSecondScore
            // 
            this.lblSecondScore.AutoSize = true;
            this.lblSecondScore.BackColor = System.Drawing.Color.Goldenrod;
            this.lblSecondScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondScore.Location = new System.Drawing.Point(36, 97);
            this.lblSecondScore.Name = "lblSecondScore";
            this.lblSecondScore.Size = new System.Drawing.Size(140, 24);
            this.lblSecondScore.TabIndex = 6;
            this.lblSecondScore.Text = "Second score";
            // 
            // lblFirstScore
            // 
            this.lblFirstScore.AutoSize = true;
            this.lblFirstScore.BackColor = System.Drawing.Color.Goldenrod;
            this.lblFirstScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstScore.Location = new System.Drawing.Point(36, 61);
            this.lblFirstScore.Name = "lblFirstScore";
            this.lblFirstScore.Size = new System.Drawing.Size(108, 24);
            this.lblFirstScore.TabIndex = 5;
            this.lblFirstScore.Text = "First score";
            // 
            // txtFourthScore
            // 
            this.txtFourthScore.BackColor = System.Drawing.Color.Goldenrod;
            this.txtFourthScore.Location = new System.Drawing.Point(194, 181);
            this.txtFourthScore.Name = "txtFourthScore";
            this.txtFourthScore.Size = new System.Drawing.Size(95, 20);
            this.txtFourthScore.TabIndex = 4;
            // 
            // txtThirdScore
            // 
            this.txtThirdScore.BackColor = System.Drawing.Color.Goldenrod;
            this.txtThirdScore.Location = new System.Drawing.Point(193, 137);
            this.txtThirdScore.Name = "txtThirdScore";
            this.txtThirdScore.Size = new System.Drawing.Size(95, 20);
            this.txtThirdScore.TabIndex = 3;
            // 
            // txtSecondScore
            // 
            this.txtSecondScore.BackColor = System.Drawing.Color.Goldenrod;
            this.txtSecondScore.Location = new System.Drawing.Point(194, 101);
            this.txtSecondScore.Name = "txtSecondScore";
            this.txtSecondScore.Size = new System.Drawing.Size(95, 20);
            this.txtSecondScore.TabIndex = 2;
            // 
            // txtFirstScore
            // 
            this.txtFirstScore.BackColor = System.Drawing.Color.Goldenrod;
            this.txtFirstScore.Location = new System.Drawing.Point(194, 65);
            this.txtFirstScore.Name = "txtFirstScore";
            this.txtFirstScore.Size = new System.Drawing.Size(95, 20);
            this.txtFirstScore.TabIndex = 1;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::event_managment.Properties.Resources.new_stadium_2;
            this.pictureBox3.Location = new System.Drawing.Point(3, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(765, 384);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::event_managment.Properties.Resources.new_stadium_2;
            this.pictureBox1.Location = new System.Drawing.Point(0, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(775, 357);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::event_managment.Properties.Resources.new_stadium_2;
            this.pictureBox2.Location = new System.Drawing.Point(-4, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(776, 365);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(14, 32);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(551, 303);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::event_managment.Properties.Resources.new_stadium_2;
            this.pictureBox4.Location = new System.Drawing.Point(19, 19);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(766, 347);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.AddEvent.ResumeLayout(false);
            this.AddEvent.PerformLayout();
            this.AddPlayers.ResumeLayout(false);
            this.AddPlayers.PerformLayout();
            this.AddTeam.ResumeLayout(false);
            this.AddTeam.PerformLayout();
            this.Score.ResumeLayout(false);
            this.Score.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAddNewPlayer;
        private System.Windows.Forms.TextBox txtPlayer;
        private System.Windows.Forms.ListBox lstPlayers;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage AddPlayers;
        private System.Windows.Forms.TabPage AddTeam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnAddTeam;
        private System.Windows.Forms.ListBox lstTeams;
        private System.Windows.Forms.Label AddNewTeam;
        private System.Windows.Forms.TextBox txtTeams;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage AddEvent;
        private System.Windows.Forms.Button btnAddNewEvent;
        private System.Windows.Forms.ListBox lstEvents;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEvent;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabPage Score;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblFourthScore;
        private System.Windows.Forms.Label lblThirdScore;
        private System.Windows.Forms.Label lblSecondScore;
        private System.Windows.Forms.Label lblFirstScore;
        private System.Windows.Forms.TextBox txtFourthScore;
        private System.Windows.Forms.TextBox txtThirdScore;
        private System.Windows.Forms.TextBox txtSecondScore;
        private System.Windows.Forms.TextBox txtFirstScore;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ListBox lstScores;
        private System.Windows.Forms.Label lblTotalScore;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox txtTeam;
        private System.Windows.Forms.Label lblTeam;
    }
}

